package newname

import (
	"fmt"

	"example.com/newname/internal"
)

func main() {
	fmt.Println(internal.Greet("world"))
	fmt.Printf("2 + 3 = %d\n", internal.Add(2, 3))
}
