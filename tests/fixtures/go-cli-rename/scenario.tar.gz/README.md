# newname

Tiny CLI tool called `newname`.

## Build

```
go build ./cmd/newname
```
