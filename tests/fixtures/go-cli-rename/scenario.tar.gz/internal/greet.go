package internal

func Greet(name string) string {
	return "hello, " + name
}
