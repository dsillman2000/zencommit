module example.com/newname

go 1.22
