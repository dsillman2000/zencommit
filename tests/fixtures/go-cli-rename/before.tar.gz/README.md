# oldname

Tiny CLI tool called `oldname`.

## Build

```
go build ./cmd/oldname
```
