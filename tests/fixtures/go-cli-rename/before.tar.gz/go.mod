module example.com/oldname

go 1.22
