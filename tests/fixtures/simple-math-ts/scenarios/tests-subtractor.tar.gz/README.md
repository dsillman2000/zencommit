# simple-math

A minimal TypeScript project with arithmetic classes.


Second version with documentation updates.
