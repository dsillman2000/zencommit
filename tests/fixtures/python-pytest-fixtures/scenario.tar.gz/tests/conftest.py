import pytest


@pytest.fixture
def base_numbers() -> tuple[int, int]:
    """Provide a reusable pair of integers for tests."""
    return (5, 3)
