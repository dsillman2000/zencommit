from src.math_ops import subtract


def test_subtract_positive():
    assert subtract(5, 3) == 2


def test_subtract_zero():
    assert subtract(7, 7) == 0


def test_subtract_with_fixture(base_numbers):
    a, b = base_numbers
    assert subtract(a, b) == 2
