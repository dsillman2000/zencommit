from src.math_ops import add


def test_add_positive():
    assert add(2, 3) == 5


def test_add_zero():
    assert add(0, 0) == 0


def test_add_with_fixture(base_numbers):
    a, b = base_numbers
    assert add(a, b) == 8
