# math_ops

A tiny math operations library with an add and a subtract function.

## Usage

```python
from math_ops import add, subtract
add(2, 3)       # 5
subtract(5, 2)  # 3
```
