use calc::{add, div, mul};

#[test]
fn add_works() {
    assert_eq!(add(2, 3), 5);
}

#[test]
fn mul_works() {
    assert_eq!(mul(2, 3), 6);
}

#[test]
fn div_works() {
    assert_eq!(div(6, 3), Ok(2));
    assert!(div(1, 0).is_err());
}
