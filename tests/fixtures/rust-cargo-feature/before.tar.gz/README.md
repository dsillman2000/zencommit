# calc

A tiny Rust crate that provides integer arithmetic helpers.

## Usage

```rust
assert_eq!(calc::add(2, 3), 5);
```
