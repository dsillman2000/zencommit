import { ApiServer } from "./api.js";
import { AuthStore } from "./auth.js";

export * from "./types.js";
export * from "./utils.js";
export * from "./auth.js";
export * from "./api.js";

export function createApp() {
  const auth = new AuthStore();
  const api = new ApiServer(auth);
  return { auth, api };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const { auth, api } = createApp();
  const u = auth.register({ name: 'demo', email: 'demo@example.com', role: 'admin' });
  auth.login(u.id);
  const r = api.create({ ownerId: u.id, name: 'Hello World', body: 'greetings' });
  console.log(`created ${r.id}: ${r.name}`);
}
