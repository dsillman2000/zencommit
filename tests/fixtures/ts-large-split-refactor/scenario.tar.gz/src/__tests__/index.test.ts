import { AuthStore, ApiServer, createApp } from "../index.js";

const assert = (cond: unknown, msg: string): void => {
  if (!cond) throw new Error(`assertion failed: ${msg}`);
};

const test = (name: string, fn: () => void): void => {
  try {
    fn();
    console.log(`  ok ${name}`);
  } catch (e) {
    console.error(`  FAIL ${name}: ${(e as Error).message}`);
    process.exitCode = 1;
  }
};

test('createApp wires auth and api', () => {
  const { auth, api } = createApp();
  assert(auth instanceof AuthStore, 'auth is AuthStore');
  assert(api instanceof ApiServer, 'api is ApiServer');
});

test('auth register/login context', () => {
  const auth = new AuthStore();
  const u = auth.register({ name: 'A', email: 'a@example.com', role: 'admin' });
  auth.login(u.id);
  const ctx = auth.context(u.id);
  assert(ctx.user?.id === u.id, 'user present');
  assert(ctx.session !== null, 'session present');
});

test('api create requires editor or admin', () => {
  const { auth, api } = createApp();
  const editor = auth.register({ name: 'E', email: 'e@example.com', role: 'editor' });
  const r = api.create({ ownerId: editor.id, name: 'Doc', body: 'hi' });
  assert(r.name === 'Doc', 'doc created');
});
