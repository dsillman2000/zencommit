export type UserId = string;
export type Role = 'admin' | 'editor' | 'viewer';

export interface User {
  id: UserId;
  name: string;
  email: string;
  role: Role;
  createdAt: Date;
}

export interface Resource {
  id: string;
  ownerId: UserId;
  name: string;
  body: string;
}

export interface Session {
  userId: UserId;
  startedAt: Date;
  expiresAt: Date;
}
