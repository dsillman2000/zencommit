import { slugify } from "./utils.js";
import type { AuthStore } from "./auth.js";
import type { Resource, UserId } from "./types.js";

export class ApiServer {
  private resources = new Map<string, Resource>();
  constructor(private auth: AuthStore) {}

  list(ownerId?: UserId): Resource[] {
    const all = Array.from(this.resources.values());
    return ownerId ? all.filter(r => r.ownerId === ownerId) : all;
  }

  get(id: string): Resource | null {
    return this.resources.get(id) ?? null;
  }

  create(input: { ownerId: UserId; name: string; body: string }): Resource {
    const ctx = this.auth.context(input.ownerId);
    if (!ctx.user) throw new Error('unauthenticated');
    if (!this.auth.hasRole(input.ownerId, 'admin') && !this.auth.hasRole(input.ownerId, 'editor')) {
      throw new Error('forbidden');
    }
    const r: Resource = {
      id: slugify(input.name) + '-' + Math.random().toString(36).slice(2, 8),
      ownerId: input.ownerId,
      name: input.name,
      body: input.body,
    };
    this.resources.set(r.id, r);
    return r;
  }

  update(id: string, patch: Partial<Pick<Resource, 'name' | 'body'>>): Resource {
    const r = this.resources.get(id);
    if (!r) throw new Error('not found');
    if (patch.name) r.name = patch.name;
    if (patch.body) r.body = patch.body;
    return r;
  }

  remove(id: string, by: UserId): void {
    const r = this.resources.get(id);
    if (!r) throw new Error('not found');
    if (r.ownerId !== by && !this.auth.hasRole(by, 'admin')) throw new Error('forbidden');
    this.resources.delete(id);
  }
}
