import { now } from "./utils.js";
import type { Role, Session, User, UserId } from "./types.js";

export interface AuthContext {
  session: Session | null;
  user: User | null;
}

export class AuthStore {
  private sessions = new Map<UserId, Session>();
  private users = new Map<UserId, User>();

  register(u: Omit<User, 'id' | 'createdAt'> & { id?: UserId }): User {
    const id = u.id ?? crypto.randomUUID();
    const user: User = { id, name: u.name, email: u.email, role: u.role, createdAt: now() };
    this.users.set(id, user);
    return user;
  }

  login(userId: UserId, durationMs = 60 * 60 * 1000): Session {
    const u = this.users.get(userId);
    if (!u) throw new Error('user not found');
    const session: Session = { userId, startedAt: now(), expiresAt: new Date(Date.now() + durationMs) };
    this.sessions.set(userId, session);
    return session;
  }

  logout(userId: UserId): void {
    this.sessions.delete(userId);
  }

  context(userId: UserId): AuthContext {
    const session = this.sessions.get(userId) ?? null;
    if (session && session.expiresAt < now()) {
      this.sessions.delete(userId);
      return { session: null, user: null };
    }
    return { session, user: this.users.get(userId) ?? null };
  }

  hasRole(userId: UserId, role: Role): boolean {
    const u = this.users.get(userId);
    return !!u && u.role === role;
  }
}
