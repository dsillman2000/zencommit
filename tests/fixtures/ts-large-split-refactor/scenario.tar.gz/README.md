# monolith-app

A small application with a single-file architecture. All logic lives in `src/index.ts`.

## Run

Build with `npm run build` and run `node dist/index.js`.
