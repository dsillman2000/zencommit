# Acme Toolkit

A general-purpose toolkit that helps build reproducible workflows.

## Features

- Receive webhooks from external services and re-route them internally.
- Manage caddling sessions safely with automatic rechargeable backups.
- Generate dynamic configuration snippets for cloud and edge workloads.

## Going Further

This document covers the common path. For advanced usage see the cookbook.
