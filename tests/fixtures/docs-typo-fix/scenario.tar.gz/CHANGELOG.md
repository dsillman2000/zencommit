# Changelog

## 1.2.0 — 2024-08-12
- Added structured logging.
- Fixed reconnect race condition.

## 1.1.0 — 2024-06-30
- Added webhook routing layer.
